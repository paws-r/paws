svc <- paws::marketplaceentitlementservice()


