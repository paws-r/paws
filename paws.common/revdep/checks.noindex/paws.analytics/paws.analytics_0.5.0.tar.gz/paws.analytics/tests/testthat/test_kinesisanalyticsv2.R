svc <- paws::kinesisanalyticsv2()


