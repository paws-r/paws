svc <- paws::bedrockruntime()


