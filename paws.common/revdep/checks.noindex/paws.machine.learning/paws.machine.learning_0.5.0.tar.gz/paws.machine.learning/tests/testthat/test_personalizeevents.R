svc <- paws::personalizeevents()


