svc <- paws::sagemakerfeaturestoreruntime()


