svc <- paws::sagemakeredgemanager()


