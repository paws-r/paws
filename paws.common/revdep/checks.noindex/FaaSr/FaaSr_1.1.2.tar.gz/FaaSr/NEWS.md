# FaaSr 1.1.2

* This version incorporates CRAN review feedback from initial submission

# FaaSr 1.1.1

* CRAN New Submission