#' @importFrom paws.common paginate
#' @export
paws.common::paginate

#' @importFrom paws.common paginate_lapply
#' @export
paws.common::paginate_lapply

#' @importFrom paws.common paginate_sapply
#' @export
paws.common::paginate_sapply

#' @importFrom paws.common list_paginators
#' @export
paws.common::list_paginators

#' @importFrom paws.common config
#' @export
paws.common::config

#' @importFrom paws.common credentials
#' @export
paws.common::credentials

#' @importFrom paws.common creds
#' @export
paws.common::creds
