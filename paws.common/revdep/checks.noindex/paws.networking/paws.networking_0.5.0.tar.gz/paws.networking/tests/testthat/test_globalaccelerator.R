svc <- paws::globalaccelerator()


