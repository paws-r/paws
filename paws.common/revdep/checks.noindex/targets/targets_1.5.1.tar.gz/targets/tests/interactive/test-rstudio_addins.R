# Select the Addins dropdown
# and go through each {targets} addin one by one.
tar_script()
# For loading and reading the target at the cursor:
# summary
# Then clean up.
tar_destroy()
unlink("_targets.R")
