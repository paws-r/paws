crew_private <- function(object) {
  skip_on_cran()
  object$.__enclos_env__$private
}
