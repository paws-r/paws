svc <- paws::licensemanager()


